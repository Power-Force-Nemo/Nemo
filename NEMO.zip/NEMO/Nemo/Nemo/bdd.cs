﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nemo
{
    internal class bdd
    {
        #region Initialize

        #endregion

        #region OpenConnection

        #endregion

        #region CloseConnection

        #endregion
    }
}
